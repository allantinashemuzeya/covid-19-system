
<?php $__env->startSection('content'); ?>

    <div class="section bg-white">
        <div class="section">
            <div class="container">
                <div class="row justify-content-center">

                    <div class="col-12 col-md-4 col-lg-3 py-3">
                        <div class=" bg-light border p-3">
                            <h2 class="text-primary"><strong>Verify Results Process</strong></h2>
                            <ol class="steps">
                                <li class="steps-item "><span>1</span> Patient Information</li>
                                <li class="steps-item active"><span>2</span> Complete</li>
                            </ol>
                        </div>
                    </div>

                    <div class="col-12 col-md-8 col-lg-9 py-5">
						<?php if($patientData !== null): ?>
                        <h1 style="color: rgb(55, 192, 55); font-size: 2em">Verified</h1>
							<?php else: ?>
								<h1 style="color: rgb(180, 20, 20); font-size: 3em; font-weight: bold">PATIENT NOT FOUND</h1>
						<?php endif; ?>

                    </div>

				<?php if($patientData !== null): ?>
                    <div class="col-12 col-md-8 col-lg-9 py-5">
                        <h2 style="color: black ">Patient:</h2>
                        <h1><?php echo e($patientData->firstName); ?> <?php echo e($patientData->lastName); ?></h1>
                    </div>


                    <div class="col-12 col-md-8 col-lg-9 py-5">
                        <h2 style="color: black ">Test type:</h2>
                        <h1>SARS-COV2 [COVID-19] RT-PCR</h1>
                    </div>


                    <div class="col-12 col-md-8 col-lg-9 py-5">
                        <h2 style="color: black ">Sample Collection Date:</h2>
                        <h1><?php echo e($patientData->collection_date); ?></h1>
                    </div>


                    <div class="col-12 col-md-8 col-lg-9 py-5">
                        <h2 style="color: black ">RESULT:</h2>
                        <h1 style="color: green "><?php echo e($patientData->result); ?></h1>
                    </div>
				<?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\OneDrive\desktop\COVID-19\covid_test_system\resources\views/Verified.blade.php ENDPATH**/ ?>