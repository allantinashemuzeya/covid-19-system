<?php

namespace App\Http\Controllers;

use App\Models\Patients;
use Symfony\Component\HttpFoundation\Request;
use Illuminate\Routing\Controller as BaseController; 

class VerifyController extends BaseController{

    public function verificationForm(){
        return view('VerificationForm');
    }

    public function verify(Request $request){

        
        // Fetch Patient Details
        $patientData = Patients::where('passportNumber', $request->IdentityNumber)->first();
        
        if($patientData !== null){
            return view('Verified', ['patientData' => $patientData]);
        }
        else{
            $patientData = null;
            return view('Verified', ['patientData' => $patientData]);
        }
    }
        
}